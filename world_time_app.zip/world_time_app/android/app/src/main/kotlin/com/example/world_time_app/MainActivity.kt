package com.example.world_time_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
